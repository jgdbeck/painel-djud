# Painel DJUD — Priorização e acompanhamento de demandas

Plataforma para organizar as demandas de dados do DJUD (judicialização de medicamentos) por **coordenação**, **prioridade** e **complexidade**, e acompanhar a **execução** de cada uma.

## Estrutura

```
projeto/
├── frontend/
│   └── index.html         → a interface (tela de início, demandas, acompanhamento)
├── backend/
│   ├── app/               → API FastAPI (login + CRUD de demandas)
│   ├── carregar_demandas.py
│   ├── criar_usuario.py
│   ├── requirements.txt
│   ├── docker-compose.yml
│   └── README.md          → como rodar a API
└── ESPECIFICACAO.md       → visão técnica para a equipe da UFSC
```

## Dois modos de uso

- **Demonstração** — abra o `frontend/index.html` (ou hospede no GitHub Pages). Funciona sozinho, salvando no navegador. Bom para apresentar.
- **Conectado (UFSC)** — suba o `backend/` num servidor da UFSC e preencha `CONFIG.API_BASE` no `index.html` com o endereço da API. Aí o painel passa a ter **login** e **dados compartilhados** entre todos.

## Por onde começar

1. **Ver funcionando:** abra `frontend/index.html` no navegador.
2. **Subir a API:** siga o `backend/README.md` (roda com SQLite em 2 minutos; PostgreSQL via Docker para produção).
3. **Conectar:** ponha o endereço da API em `CONFIG.API_BASE` no `index.html`.

Detalhes de arquitetura, modelo de dados e decisões: veja `ESPECIFICACAO.md`.
