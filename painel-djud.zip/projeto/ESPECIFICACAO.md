# Especificação técnica — Painel DJUD

Documento para a equipe de desenvolvimento da UFSC. Descreve a arquitetura, o modelo de dados e o que é preciso para colocar a ferramenta em produção interna (com login e dados compartilhados).

## 1. Objetivo

Sair de um HTML de demonstração (edições salvas só no navegador) para uma **ferramenta multiusuário**, hospedada na infraestrutura da UFSC, com:

1. **Dados compartilhados** — o que uma pessoa altera, todas veem.
2. **Login com dois papéis** — *editor* (altera) e *leitor* (só visualiza).
3. **Painel gerencial** — execução por prioridade, complexidade e coordenação.

## 2. Arquitetura

Três camadas, todas sob controle da UFSC:

```
[ Navegador ]  --HTTPS-->  [ API FastAPI ]  -->  [ PostgreSQL ]
  index.html               (login + CRUD)        (demandas, usuários)
```

- **Frontend:** `frontend/index.html` — HTML/CSS/JS puro, sem build. Pode ser servido pelo GitHub Pages **ou** por um servidor da UFSC. Já vem preparado para os dois modos (a chave é a constante `CONFIG.API_BASE`).
- **Backend:** `backend/` — FastAPI. Faz login (JWT) e expõe o CRUD de demandas. Já implementado e testado.
- **Banco:** PostgreSQL em produção (SQLite em desenvolvimento).

## 3. Modelo de dados

**usuarios**

| campo | tipo | notas |
|---|---|---|
| id | serial | PK |
| email | texto | único |
| nome | texto | |
| senha_hash | texto | bcrypt |
| papel | texto | `editor` \| `leitor` |

**demandas**

| campo | tipo | valores |
|---|---|---|
| id | texto | ex.: `d01` |
| coord | texto | nome da coordenação |
| titulo | texto | |
| oque | texto | descrição ("o que entrega") |
| fonte | texto | origem do dado |
| acesso | texto | status de acesso à fonte |
| prio | texto | `1` \| `2` \| `3` \| `A definir` (1 = mais alta) |
| comp | texto | `Baixa` \| `Média` \| `Alta` \| `Muito alta` |
| status | texto | `Não iniciada` \| `Em andamento` \| `Concluída` |
| pct | inteiro | 0–100 (execução) |
| obs | texto | observação da prioridade |
| warn | texto | alerta opcional |

> **Prioridade** e **complexidade** são intencionalmente distintas: prioridade é a importância (decisão da área/direção); complexidade é a leitura técnica de esforço e acesso.

## 4. API (já implementada)

| Método | Rota | Papel | Descrição |
|---|---|---|---|
| POST | `/auth/login` | — | `{email, password}` → `{access_token, role, email}` |
| GET | `/auth/me` | autenticado | dados do logado |
| GET | `/demandas` | autenticado | lista |
| POST | `/demandas` | editor | cria |
| PUT | `/demandas/{id}` | editor | atualiza |
| DELETE | `/demandas/{id}` | editor | exclui |
| GET | `/health` | — | verificação |

Autenticação por **JWT** no header `Authorization: Bearer <token>`. Papéis validados no backend (o leitor recebe 403 em operações de escrita).

## 5. Conexão do frontend

No `index.html`, o objeto `CONFIG.API_BASE` decide o modo:

- `""` → modo demonstração (localStorage, sem login).
- URL da API → modo conectado (login + dados no servidor).

O frontend abstrai isso num "store" com as operações `list / create / update / remove`, que em modo conectado viram chamadas à API. Não é preciso reescrever a interface para produção — só apontar o endereço.

## 6. Passos para produção na UFSC

1. Provisionar uma VM/servidor (Linux) e um PostgreSQL.
2. Subir o backend (Docker `compose up` já configurado, ou uvicorn atrás de nginx).
3. Definir `SECRET_KEY` forte e `CORS_ORIGINS` = domínio do frontend.
4. Rodar `carregar_demandas.py` (carga inicial) e `criar_usuario.py` para cada pessoa.
5. Publicar o frontend (GitHub Pages ou servidor UFSC) com `CONFIG.API_BASE` apontando para a API.
6. Servir tudo sob **HTTPS**.

## 7. Evoluções possíveis (futuro)

- **Histórico/auditoria** — tabela de log de alterações (quem mudou o quê e quando).
- **SSO institucional** — trocar login e-mail/senha por autenticação única da UFSC/Ministério.
- **Integração de dados** — alimentar `status`/`pct` a partir de fontes (SEI, SISMAT, SIAFI) quando os acessos forem liberados; e integração ao SISDJUD/Databricks.
- **Macro/eixos** — se a Secretaria Executiva quiser um agrupamento acima de coordenação, adicionar um campo `macro` (o frontend já agrupa/filtra por campos).

## 8. Escopo de dados

A ferramenta guarda apenas **dados de gestão do projeto** (título, prioridade, complexidade, status). Não armazena dado sensível de paciente — esse permanece nas fontes originais. Isso mantém o sistema leve e reduz exigências de conformidade.
