# Painel DJUD — Backend (API)

API em **FastAPI + PostgreSQL** que guarda as demandas de forma compartilhada e faz **login** com dois papéis: **editor** (altera) e **leitor** (só visualiza). É o que transforma o painel HTML de "demonstração no navegador" em ferramenta multiusuário.

> Para desenvolvimento roda com **SQLite** sem instalar banco nenhum. Em produção, use **PostgreSQL** (via Docker ou servidor da UFSC).

---

## Opção A — Rodar rápido para testar (SQLite)

Requer Python 3.11+.

```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python carregar_demandas.py                             # carrega as 35 demandas
python criar_usuario.py joao@ufsc.br "Senha123" editor "João"
python criar_usuario.py leitor@ufsc.br "Senha123" leitor

uvicorn app.main:app --reload
```

A API sobe em `http://localhost:8000`. Documentação interativa: `http://localhost:8000/docs`.

## Opção B — Rodar com PostgreSQL (Docker)

Requer Docker.

```bash
cd backend
docker compose up --build -d          # sobe Postgres + API
# carga inicial e usuários dentro do container:
docker compose exec api python carregar_demandas.py
docker compose exec api python criar_usuario.py joao@ufsc.br "Senha123" editor "João"
```

---

## Configuração (.env)

Copie `.env.example` para `.env` e ajuste:

- `DATABASE_URL` — conexão do banco (SQLite em dev; PostgreSQL em produção).
- `SECRET_KEY` — chave que assina os tokens de login. **Troque** por algo secreto (`openssl rand -hex 32`).
- `CORS_ORIGINS` — endereços do frontend autorizados a chamar a API (ex.: o link do GitHub Pages e/ou o domínio da UFSC).

---

## Endpoints

| Método | Rota | Quem pode | O que faz |
|---|---|---|---|
| POST | `/auth/login` | todos | Recebe `{email, password}`, devolve `access_token` e `role` |
| GET | `/auth/me` | autenticado | Dados do usuário logado |
| GET | `/demandas` | autenticado | Lista todas as demandas |
| POST | `/demandas` | **editor** | Cria uma demanda |
| PUT | `/demandas/{id}` | **editor** | Atualiza uma demanda |
| DELETE | `/demandas/{id}` | **editor** | Exclui uma demanda |
| GET | `/health` | todos | Verifica se a API está no ar |

O token vai no cabeçalho `Authorization: Bearer <token>` nas rotas protegidas.

---

## Conectar o frontend

No arquivo `index.html`, no topo do `<script>`, preencha:

```js
const CONFIG = { API_BASE: "https://SEU-ENDERECO-DA-UFSC/api" };
```

Com isso o painel deixa de salvar no navegador e passa a **pedir login** e a **ler/gravar na API** — dados compartilhados entre todos. Deixe `API_BASE: ""` para voltar ao modo demonstração.

---

## Gerenciar usuários

```bash
python criar_usuario.py email@ufsc.br "Senha" editor "Nome"   # cria/atualiza editor
python criar_usuario.py email@ufsc.br "Senha" leitor          # cria/atualiza leitor
```

Rodar de novo com o mesmo e-mail **atualiza** a senha/papel.

---

## Observações de segurança (produção)

- Servir a API sob **HTTPS**.
- `SECRET_KEY` forte e fora do código (variável de ambiente).
- Restringir `CORS_ORIGINS` ao domínio real do frontend (não deixar `*`).
- Backup do PostgreSQL.
