# -*- coding: utf-8 -*-
"""Autenticação: hash de senha (bcrypt) e tokens JWT."""
from datetime import datetime, timedelta, timezone
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
import bcrypt
from sqlalchemy.orm import Session

from .config import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES
from .database import get_db
from . import models

oauth2 = OAuth2PasswordBearer(tokenUrl="auth/login", auto_error=False)


def hash_password(p: str) -> str:
    # bcrypt aceita no máximo 72 bytes; truncamos por segurança.
    return bcrypt.hashpw(p.encode("utf-8")[:72], bcrypt.gensalt()).decode("utf-8")


def verify_password(p: str, h: str) -> bool:
    try:
        return bcrypt.checkpw(p.encode("utf-8")[:72], h.encode("utf-8"))
    except Exception:
        return False


def create_token(email: str, role: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode({"sub": email, "role": role, "exp": exp}, SECRET_KEY, algorithm=ALGORITHM)


def current_user(token: str = Depends(oauth2), db: Session = Depends(get_db)) -> models.User:
    cred_err = HTTPException(status.HTTP_401_UNAUTHORIZED, "Não autenticado",
                            headers={"WWW-Authenticate": "Bearer"})
    if not token:
        raise cred_err
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("sub")
    except JWTError:
        raise cred_err
    user = db.query(models.User).filter(models.User.email == email).first()
    if not user:
        raise cred_err
    return user


def require_editor(user: models.User = Depends(current_user)) -> models.User:
    if user.papel != "editor":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Ação permitida apenas para editores.")
    return user
