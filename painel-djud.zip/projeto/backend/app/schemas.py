# -*- coding: utf-8 -*-
"""Formatos de entrada/saída da API (validação)."""
from typing import Optional
from pydantic import BaseModel, EmailStr


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    email: str


class DemandaIn(BaseModel):
    id: Optional[str] = None
    coord: str = ""
    titulo: str = ""
    oque: str = ""
    fonte: str = ""
    acesso: str = ""
    prio: str = "A definir"
    comp: str = "Média"
    status: str = "Não iniciada"
    pct: int = 0
    obs: str = ""
    warn: str = ""
    produto: str = ""
    prazo: str = "A definir"


class DemandaOut(DemandaIn):
    id: str


class UserIn(BaseModel):
    email: EmailStr
    nome: str = ""
    password: str
    papel: str = "leitor"  # "editor" | "leitor"
