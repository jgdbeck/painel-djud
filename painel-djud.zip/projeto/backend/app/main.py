# -*- coding: utf-8 -*-
"""API do Painel DJUD — login e CRUD de demandas.

Rodar em desenvolvimento:
    uvicorn app.main:app --reload
Documentação interativa: http://localhost:8000/docs
"""
from typing import List
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from .config import CORS_ORIGINS
from .database import Base, engine, get_db
from . import models, schemas, auth

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Painel DJUD — API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"ok": True}


# ---------- autenticação ----------
@app.post("/auth/login", response_model=schemas.TokenOut)
def login(data: schemas.LoginIn, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == data.email).first()
    if not user or not auth.verify_password(data.password, user.senha_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "E-mail ou senha inválidos.")
    token = auth.create_token(user.email, user.papel)
    return {"access_token": token, "token_type": "bearer", "role": user.papel, "email": user.email}


@app.get("/auth/me")
def me(user: models.User = Depends(auth.current_user)):
    return {"email": user.email, "nome": user.nome, "role": user.papel}


# ---------- demandas ----------
@app.get("/demandas", response_model=List[schemas.DemandaOut])
def listar(db: Session = Depends(get_db), user: models.User = Depends(auth.current_user)):
    return [d.as_dict() for d in db.query(models.Demanda).all()]


@app.post("/demandas", response_model=schemas.DemandaOut, status_code=201)
def criar(data: schemas.DemandaIn, db: Session = Depends(get_db),
          user: models.User = Depends(auth.require_editor)):
    novo_id = data.id or _novo_id(db)
    if db.get(models.Demanda, novo_id):
        raise HTTPException(status.HTTP_409_CONFLICT, "Já existe demanda com este id.")
    d = models.Demanda(**{**data.model_dump(), "id": novo_id})
    db.add(d); db.commit(); db.refresh(d)
    return d.as_dict()


@app.put("/demandas/{demanda_id}", response_model=schemas.DemandaOut)
def atualizar(demanda_id: str, data: schemas.DemandaIn, db: Session = Depends(get_db),
              user: models.User = Depends(auth.require_editor)):
    d = db.get(models.Demanda, demanda_id)
    if not d:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Demanda não encontrada.")
    for k, v in data.model_dump(exclude={"id"}).items():
        setattr(d, k, v)
    db.commit(); db.refresh(d)
    return d.as_dict()


@app.delete("/demandas/{demanda_id}", status_code=204)
def excluir(demanda_id: str, db: Session = Depends(get_db),
            user: models.User = Depends(auth.require_editor)):
    d = db.get(models.Demanda, demanda_id)
    if not d:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Demanda não encontrada.")
    db.delete(d); db.commit()
    return None


def _novo_id(db: Session) -> str:
    """Gera um id sequencial tipo d01, d02… buscando o maior existente."""
    ids = [d.id for d in db.query(models.Demanda.id).all()]
    n = 0
    for i in ids:
        if i and i.startswith("d") and i[1:].isdigit():
            n = max(n, int(i[1:]))
    return f"d{n+1:02d}"
