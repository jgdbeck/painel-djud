# -*- coding: utf-8 -*-
"""Tabelas do banco: usuários e demandas."""
from sqlalchemy import Column, String, Integer, Text
from .database import Base


class User(Base):
    __tablename__ = "usuarios"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    nome = Column(String(255), default="")
    senha_hash = Column(String(255), nullable=False)
    papel = Column(String(20), default="leitor")  # "editor" ou "leitor"


class Demanda(Base):
    __tablename__ = "demandas"
    # id textual (ex.: "d01") para casar com o frontend/seed
    id = Column(String(40), primary_key=True, index=True)
    coord = Column(String(120), default="")
    titulo = Column(String(300), default="")
    oque = Column(Text, default="")
    fonte = Column(Text, default="")
    acesso = Column(String(200), default="")
    prio = Column(String(20), default="A definir")   # "1" | "2" | "3" | "A definir"
    comp = Column(String(20), default="Média")       # Baixa | Média | Alta | Muito alta
    status = Column(String(20), default="Não iniciada")
    pct = Column(Integer, default=0)
    obs = Column(String(200), default="")
    warn = Column(String(200), default="")
    produto = Column(String(120), default="")
    prazo = Column(String(20), default="A definir")

    def as_dict(self):
        return {
            "id": self.id, "coord": self.coord, "titulo": self.titulo, "oque": self.oque,
            "fonte": self.fonte, "acesso": self.acesso, "prio": self.prio, "comp": self.comp,
            "status": self.status, "pct": self.pct, "obs": self.obs, "warn": self.warn,
            "produto": self.produto, "prazo": self.prazo,
        }
