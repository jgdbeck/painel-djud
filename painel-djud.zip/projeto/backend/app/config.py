# -*- coding: utf-8 -*-
"""Configuração central do backend, lida de variáveis de ambiente (.env)."""
import os

# Banco: por padrão usa SQLite (roda na hora, sem instalar nada).
# Em produção na UFSC, aponte para o PostgreSQL, ex.:
#   DATABASE_URL=postgresql+psycopg://usuario:senha@localhost:5432/painel_djud
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./painel_djud.db")

# Chave usada para assinar os tokens de login (JWT).
# TROQUE por um valor longo e secreto em produção (ex.: openssl rand -hex 32).
SECRET_KEY = os.getenv("SECRET_KEY", "troque-esta-chave-em-producao-por-uma-secreta")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "480"))  # 8h

# Origens autorizadas a chamar a API (o endereço do frontend).
# Separe por vírgula. Ex.: CORS_ORIGINS=https://jgdbeck.github.io,https://painel.saude.ufsc.br
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()]
