# -*- coding: utf-8 -*-
"""Carga inicial das demandas a partir de seed_cards.json.

Uso:
    python carregar_demandas.py           # insere as que faltam (não duplica)
    python carregar_demandas.py --reset   # apaga tudo e recarrega do zero
"""
import json, sys, os
from app.database import Base, engine, SessionLocal
from app import models

Base.metadata.create_all(bind=engine)
AQUI = os.path.dirname(__file__)

def main():
    reset = "--reset" in sys.argv
    cards = json.load(open(os.path.join(AQUI, "seed_cards.json"), encoding="utf-8"))
    db = SessionLocal()
    if reset:
        db.query(models.Demanda).delete(); db.commit()
    inseridos = 0
    for i, c in enumerate(cards, 1):
        cid = f"d{i:02d}"
        if db.get(models.Demanda, cid):
            continue
        db.add(models.Demanda(
            id=cid, coord=c.get("coord", ""), titulo=c.get("titulo", ""), oque=c.get("oque", ""),
            fonte=c.get("fonte", ""), acesso=c.get("acesso", ""),
            prio=c.get("prio") if c.get("prio") in ("1", "2", "3") else "A definir",
            comp=c.get("comp") if c.get("comp") in ("Baixa", "Média", "Alta", "Muito alta") else "Média",
            status="Não iniciada", pct=0, obs=c.get("obs", ""), warn=c.get("warn", ""),
            produto=c.get("produto", ""), prazo=c.get("prazo", "A definir"),
        ))
        inseridos += 1
    db.commit()
    print(f"{inseridos} demandas inseridas. Total no banco: {db.query(models.Demanda).count()}.")

if __name__ == "__main__":
    main()
