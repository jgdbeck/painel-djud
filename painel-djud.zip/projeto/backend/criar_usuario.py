# -*- coding: utf-8 -*-
"""Cria (ou atualiza) um usuário.

Uso:
    python criar_usuario.py email@ufsc.br "Senha123" editor "Nome Sobrenome"
    python criar_usuario.py leitor@ufsc.br "Senha123" leitor
Papéis: editor (pode alterar) | leitor (só visualiza).
"""
import sys
from app.database import Base, engine, SessionLocal
from app import models, auth

Base.metadata.create_all(bind=engine)

def main():
    if len(sys.argv) < 4:
        print(__doc__); sys.exit(1)
    email, senha, papel = sys.argv[1], sys.argv[2], sys.argv[3]
    nome = sys.argv[4] if len(sys.argv) > 4 else ""
    if papel not in ("editor", "leitor"):
        print("Papel deve ser 'editor' ou 'leitor'."); sys.exit(1)
    db = SessionLocal()
    u = db.query(models.User).filter(models.User.email == email).first()
    if u:
        u.senha_hash = auth.hash_password(senha); u.papel = papel
        if nome: u.nome = nome
        acao = "atualizado"
    else:
        u = models.User(email=email, nome=nome, senha_hash=auth.hash_password(senha), papel=papel)
        db.add(u); acao = "criado"
    db.commit()
    print(f"Usuário {email} ({papel}) {acao} com sucesso.")

if __name__ == "__main__":
    main()
